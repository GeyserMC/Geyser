plugins {
    id("geyser.publish-conventions")
}

dependencies {
    api(libs.base.api)
}